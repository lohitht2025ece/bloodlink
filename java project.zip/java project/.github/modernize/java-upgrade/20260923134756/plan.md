# Upgrade Plan: rural-health-clinic (20260923134756)

- **Generated**: 2026-09-23
- **HEAD Branch**: existing workspace branch; preserved by version-control preparation
- **HEAD Commit ID**: existing workspace HEAD; preserved by version-control preparation

## Available Tools

**JDKs**
- JDK 17.0.20.1: `C:\Program Files\Java\jdk-17.0.20.1\bin` (current project JDK, baseline)
- JDK 25.0.3: `C:\Program Files\Java\jdk-25.0.3\bin` (target runtime and final validation)

**Build Tools**
- Maven 3.9.15: `C:\Users\lohith\.maven\maven-3.9.15\bin`

## Guidelines

- Upgrade the Java runtime to the latest LTS requested by the user, Java 25.
- Run in auto-execution mode.
- Preserve unrelated pre-existing workspace changes.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260923134756
- Run tests before and after the upgrade: true
- Auto-execution mode: true

## Upgrade Goals

- Java 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 17 | 25 | User requested Java 25 |
| Spring Boot | 3.3.3 | 3.3.3 | Existing Spring Boot line supports Java 25 compilation/runtime; no framework upgrade requested |
| Maven | 3.9.15 | 3.9.0 | Compatible with Java 25 and already installed |
| maven-compiler-plugin | Spring Boot parent managed | Java 25-capable managed version | Uses the parent-managed compiler plugin and target JDK |
| Spring Boot Maven Plugin | 3.3.3 | 3.3.3 | Existing plugin remains compatible with the requested runtime |

## Derived Upgrades

- Set Maven `java.version` to `25`, which drives compiler source/target configuration through the Spring Boot parent.
- Use Maven 3.9.15 because Java 25 is the target runtime and Maven 3.9+ is recommended.
- No Kotlin upgrade is required because the project contains no Kotlin configuration or source files.
- No Spring Boot upgrade is required because the user requested only a Java runtime upgrade and the current Spring Boot line is retained.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| `pom.xml` | `java.version` property | `17` | upgrade | `25` | Sets the project compiler/runtime target |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|-----------------|--------|
| None | N/A | No Java 25-incompatible APIs identified from the project structure | No source changes | The application uses standard Spring/JPA APIs and has no explicit JDK-internal imports or removed-JDK API references |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|-----------------|--------|
| None | N/A | No Java-version-specific application settings identified | No change | Runtime configuration is independent of the Java target |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|-----------------|
| None detected | N/A | No CI/CD files in the project scope | No change | No hardcoded Java version was found in the project files |

### Risks & Warnings

- **Java 25 compiler/runtime compatibility**: A dependency or plugin may expose an issue only during compilation or startup. **Mitigation**: Run the Java 17 baseline, then Java 25 `test-compile` and full `test` validation.
- **Pre-existing workspace changes**: The enclosing workspace contains unrelated untracked files. **Mitigation**: Use version-control `prepareBranch` so unrelated changes are preserved and the upgrade remains isolated.
- **Dependency CVEs**: The existing dependency graph may contain advisories unrelated to the Java target. **Mitigation**: Run dependency extraction and CVE validation after the upgrade; apply only required patched versions if reported.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Confirm Java 25 and Maven 3.9.15 are available before changing project files.
  - **Changes to Make**: No project changes; use the installed toolchain.
  - **Verification**: List JDKs and Maven; expected Java 25.0.3 and Maven 3.9.15 available.

- Step 2: Setup Baseline
  - **Rationale**: Establish the current Java 17 compilation and test result before the upgrade.
  - **Changes to Make**: No project changes.
  - **Verification**: `mvn clean compile test-compile -q && mvn clean test -q` with JDK 17; expected baseline recorded.

- Step 3: Upgrade Java Target to 25
  - **Rationale**: Apply the only required project configuration change.
  - **Changes to Make**: Apply the Dependency Changes and preserve all existing source/configuration behavior.
  - **Verification**: `mvn clean test-compile -q` with JDK 25; expected successful main and test compilation.

- Step 4: CVE Validation and Fix
  - **Rationale**: Confirm the post-upgrade dependency graph has no actionable known vulnerabilities.
  - **Changes to Make**: Extract direct dependencies and apply only necessary patched versions reported by the CVE scan.
  - **Verification**: Rebuild and re-scan; expected no unresolved actionable CVEs or documented unpatchable findings.

- Step 5: Final Validation
  - **Rationale**: Prove the Java 25 upgrade meets the compilation and 100% test success criteria.
  - **Changes to Make**: Resolve any Java 25 build/test failures and remove temporary workarounds.
  - **Verification**: `mvn clean test-compile -q` and `mvn clean test -q` with JDK 25; expected both successful and all tests passing.
