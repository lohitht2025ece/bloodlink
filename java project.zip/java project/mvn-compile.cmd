@echo off
set JAVA_HOME=C:\Program Files\Java\jdk-17.0.20.1
set PATH=%JAVA_HOME%\bin;%PATH%
cd /d "C:\Users\lohith\OneDrive\Desktop\java project"
"C:\Users\lohith\.maven\maven-3.9.15\bin\mvn.cmd" compile
