package com.sece.eceb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RuralHealthClinicApplication {

    public static void main(String[] args) {
        SpringApplication.run(RuralHealthClinicApplication.class, args);
    }
}
