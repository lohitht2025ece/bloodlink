package com.sece.eceb.config;

import com.sece.eceb.entity.*;
import com.sece.eceb.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Component
@SuppressWarnings("null")
public class DataInitializer implements CommandLineRunner {

    private final PatientRepository patientRepository;
    private final SupplierRepository supplierRepository;
    private final VaccineBatchRepository vaccineBatchRepository;
    private final StorageUnitRepository storageUnitRepository;
    private final TemperatureLogRepository temperatureLogRepository;
    private final ImmunizationRepository immunizationRepository;
    private final InsuranceClaimRepository insuranceClaimRepository;
    private final BudgetRepository budgetRepository;
    private final TransactionRepository transactionRepository;

    public DataInitializer(PatientRepository patientRepository,
                          SupplierRepository supplierRepository,
                          VaccineBatchRepository vaccineBatchRepository,
                          StorageUnitRepository storageUnitRepository,
                          TemperatureLogRepository temperatureLogRepository,
                          ImmunizationRepository immunizationRepository,
                          InsuranceClaimRepository insuranceClaimRepository,
                          BudgetRepository budgetRepository,
                          TransactionRepository transactionRepository) {
        this.patientRepository = patientRepository;
        this.supplierRepository = supplierRepository;
        this.vaccineBatchRepository = vaccineBatchRepository;
        this.storageUnitRepository = storageUnitRepository;
        this.temperatureLogRepository = temperatureLogRepository;
        this.immunizationRepository = immunizationRepository;
        this.insuranceClaimRepository = insuranceClaimRepository;
        this.budgetRepository = budgetRepository;
        this.transactionRepository = transactionRepository;
    }

    @Override
    public void run(String... args) {
        if (patientRepository.count() > 0) {
            return;
        }

        supplierRepository.save(new Supplier("RuralCare Pharma", "Anita Rao", "9876543210", "Village market road", "Vaccine supplies"));
        supplierRepository.save(new Supplier("Green Valley Biotech", "Suresh Nair", "9988776655", "District center", "Cold chain logistics"));

        StorageUnit storage1 = storageUnitRepository.save(new StorageUnit("Main Cold Room", "Storage Block A", 250, -20.0, 8.0, "Active"));
        StorageUnit storage2 = storageUnitRepository.save(new StorageUnit("Clinic Fridge", "Clinic Hall", 80, 2.0, 8.0, "Active"));

        Patient patient1 = patientRepository.save(new Patient("Ravi Kumar", 29, "Male", "Bhojpur", "9823456710", "State Health", "SH-1001", "Active"));
        Patient patient2 = patientRepository.save(new Patient("Sita Devi", 42, "Female", "Nandgaon", "9811122233", "Prime Care", "PC-7802", "Active"));
        Patient patient3 = patientRepository.save(new Patient("Anand Singh", 5, "Male", "Kharibera", "9877001234", "No Insurance", "N/A", "Scheduled"));

        VaccineBatch batch1 = vaccineBatchRepository.save(new VaccineBatch("BCG", "RuralCare Pharma", 140, LocalDate.of(2026, 6, 30), storage1, "BCG-2025-01", LocalDate.of(2025, 1, 12), new BigDecimal("18.50")));
        VaccineBatch batch2 = vaccineBatchRepository.save(new VaccineBatch("COVID-19", "Green Valley Biotech", 100, LocalDate.of(2025, 12, 15), storage2, "COV-2025-22", LocalDate.of(2025, 4, 2), new BigDecimal("24.00")));

        temperatureLogRepository.saveAll(List.of(
                new TemperatureLog(storage1, 2.4, "Normal range", LocalDateTime.now().minusDays(1)),
                new TemperatureLog(storage1, 9.2, "High excursion", LocalDateTime.now().minusHours(5)),
                new TemperatureLog(storage2, 4.1, "Normal range", LocalDateTime.now().minusHours(2))
        ));

        immunizationRepository.saveAll(List.of(
                new Immunization(patient1, batch1, 1, LocalDateTime.now().minusDays(20), "Left arm", "Completed"),
                new Immunization(patient2, batch2, 1, LocalDateTime.now().minusDays(8), "Right arm", "Completed"),
                new Immunization(patient3, batch1, 1, LocalDateTime.now().plusDays(2), "Left thigh", "Scheduled")
        ));

        insuranceClaimRepository.saveAll(List.of(
                new InsuranceClaim(patient1, "CLM-1001", new BigDecimal("850.00"), "Submitted", LocalDate.now().minusDays(14), new BigDecimal("620.00"), "Partially approved"),
                new InsuranceClaim(patient2, "CLM-1002", new BigDecimal("1200.00"), "Approved", LocalDate.now().minusDays(4), new BigDecimal("1200.00"), "Completed")
        ));

        budgetRepository.saveAll(List.of(
                new Budget("2025", new BigDecimal("150000.00"), new BigDecimal("62800.00"), "Immunization Program"),
                new Budget("2025", new BigDecimal("50000.00"), new BigDecimal("21450.00"), "Cold Chain Maintenance")
        ));

        transactionRepository.saveAll(List.of(
                new Transaction("Purchase", new BigDecimal("42000.00"), "Vaccine procurement", LocalDate.now().minusDays(10), "PO-101", "Inventory"),
                new Transaction("Expense", new BigDecimal("1800.00"), "Generator fuel", LocalDate.now().minusDays(3), "EXP-332", "Operations"),
                new Transaction("Refund", new BigDecimal("540.00"), "Insurance reimbursements", LocalDate.now().minusDays(1), "REF-88", "Claims")
        ));
    }
}
