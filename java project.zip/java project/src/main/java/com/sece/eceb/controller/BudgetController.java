package com.sece.eceb.controller;

import com.sece.eceb.entity.Budget;
import com.sece.eceb.repository.BudgetRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/budgets")
@SuppressWarnings("null")
public class BudgetController {
    private final BudgetRepository budgetRepository;

    public BudgetController(BudgetRepository budgetRepository) {
        this.budgetRepository = budgetRepository;
    }

    @GetMapping
    public List<Budget> getAll() { return budgetRepository.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Budget> getById(@PathVariable Long id) {
        return budgetRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Budget create(@Valid @RequestBody Budget budget) { return budgetRepository.save(budget); }

    @PutMapping("/{id}")
    public ResponseEntity<Budget> update(@PathVariable Long id, @Valid @RequestBody Budget request) {
        return budgetRepository.findById(id)
                .map(existing -> {
                    existing.setFiscalYear(request.getFiscalYear());
                    existing.setAllocatedAmount(request.getAllocatedAmount());
                    existing.setSpentAmount(request.getSpentAmount());
                    existing.setCategory(request.getCategory());
                    return ResponseEntity.ok(budgetRepository.save(existing));
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (budgetRepository.existsById(id)) {
            budgetRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
