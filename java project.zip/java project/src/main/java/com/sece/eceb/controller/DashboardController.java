package com.sece.eceb.controller;

import com.sece.eceb.repository.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class DashboardController {
    private final PatientRepository patientRepository;
    private final VaccineBatchRepository vaccineBatchRepository;
    private final InsuranceClaimRepository insuranceClaimRepository;
    private final BudgetRepository budgetRepository;
    private final TransactionRepository transactionRepository;
    private final StorageUnitRepository storageUnitRepository;

    public DashboardController(PatientRepository patientRepository,
                             VaccineBatchRepository vaccineBatchRepository,
                             InsuranceClaimRepository insuranceClaimRepository,
                             BudgetRepository budgetRepository,
                             TransactionRepository transactionRepository,
                             StorageUnitRepository storageUnitRepository) {
        this.patientRepository = patientRepository;
        this.vaccineBatchRepository = vaccineBatchRepository;
        this.insuranceClaimRepository = insuranceClaimRepository;
        this.budgetRepository = budgetRepository;
        this.transactionRepository = transactionRepository;
        this.storageUnitRepository = storageUnitRepository;
    }

    @GetMapping("/dashboard")
    public Map<String, Object> dashboard() {
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("patients", patientRepository.count());
        metrics.put("vaccines", vaccineBatchRepository.count());
        metrics.put("claims", insuranceClaimRepository.count());
        metrics.put("budgets", budgetRepository.count());
        metrics.put("transactions", transactionRepository.count());
        metrics.put("storageUnits", storageUnitRepository.count());
        return metrics;
    }
}
