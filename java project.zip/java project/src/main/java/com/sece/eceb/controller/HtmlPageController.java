package com.sece.eceb.controller;

import com.sece.eceb.entity.Budget;
import com.sece.eceb.entity.ClinicUser;
import com.sece.eceb.entity.InsuranceClaim;
import com.sece.eceb.entity.Patient;
import com.sece.eceb.entity.StorageUnit;
import com.sece.eceb.entity.Transaction;
import com.sece.eceb.entity.VaccineBatch;
import com.sece.eceb.repository.BudgetRepository;
import com.sece.eceb.repository.ClinicUserRepository;
import com.sece.eceb.repository.InsuranceClaimRepository;
import com.sece.eceb.repository.PatientRepository;
import com.sece.eceb.repository.StorageUnitRepository;
import com.sece.eceb.repository.TransactionRepository;
import com.sece.eceb.repository.VaccineBatchRepository;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Controller
@SuppressWarnings("null")
public class HtmlPageController {
    private static final String USER_NAME = "clinicUserName";
    private static final String USER_ROLE = "clinicUserRole";

    private final PatientRepository patientRepository;
    private final VaccineBatchRepository vaccineBatchRepository;
    private final StorageUnitRepository storageUnitRepository;
    private final InsuranceClaimRepository insuranceClaimRepository;
    private final BudgetRepository budgetRepository;
    private final TransactionRepository transactionRepository;
    private final ClinicUserRepository clinicUserRepository;
    private final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public HtmlPageController(PatientRepository patientRepository,
                              VaccineBatchRepository vaccineBatchRepository,
                              StorageUnitRepository storageUnitRepository,
                              InsuranceClaimRepository insuranceClaimRepository,
                              BudgetRepository budgetRepository,
                              TransactionRepository transactionRepository,
                              ClinicUserRepository clinicUserRepository) {
        this.patientRepository = patientRepository;
        this.vaccineBatchRepository = vaccineBatchRepository;
        this.storageUnitRepository = storageUnitRepository;
        this.insuranceClaimRepository = insuranceClaimRepository;
        this.budgetRepository = budgetRepository;
        this.transactionRepository = transactionRepository;
        this.clinicUserRepository = clinicUserRepository;
    }

    @GetMapping({"/", "/login"})
    public String loginPage(HttpSession session) {
        return isLoggedIn(session) ? "redirect:/dashboard" : "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {
        String identifier = username.trim();
        ClinicUser account = clinicUserRepository.findByUsernameIgnoreCase(identifier)
            .or(() -> clinicUserRepository.findByEmailIgnoreCase(identifier)).orElse(null);
        boolean demoLogin = ("admin".equalsIgnoreCase(identifier) || "admin@ruralcare.org".equalsIgnoreCase(identifier))
            && "admin123".equals(password);
        if (!demoLogin && (account == null || !passwordEncoder.matches(password, account.getPasswordHash()))) {
            model.addAttribute("loginError", "We could not match those credentials. Check them and try again.");
            return "login";
        }
        session.setAttribute(USER_NAME, demoLogin ? "Clinic Administrator" : account.getName());
        session.setAttribute(USER_ROLE, demoLogin ? "Clinic Officer" : account.getRole());
        return "redirect:/dashboard";
    }

    @PostMapping("/register")
    public String register(@RequestParam String name,
                           @RequestParam String email,
                           @RequestParam String username,
                           @RequestParam String password,
                           @RequestParam String confirmPassword,
                           @RequestParam String role,
                           Model model,
                           RedirectAttributes redirectAttributes) {
        String normalizedUsername = username.trim();
        String normalizedEmail = email.trim();
        if (name.isBlank() || normalizedEmail.isBlank() || normalizedUsername.length() < 3 || password.length() < 8) {
            model.addAttribute("registerError", "Complete all fields and use a username with 3+ characters and a password with 8+ characters.");
            return "login";
        }
        if (!password.equals(confirmPassword)) {
            model.addAttribute("registerError", "Passwords do not match.");
            return "login";
        }
        if (clinicUserRepository.existsByUsernameIgnoreCase(normalizedUsername) || clinicUserRepository.existsByEmailIgnoreCase(normalizedEmail)
            || "admin".equalsIgnoreCase(normalizedUsername) || "admin@ruralcare.org".equalsIgnoreCase(normalizedEmail)) {
            model.addAttribute("registerError", "That username or email is already registered.");
            return "login";
        }
        if (!List.of("Clinic Officer", "Program Manager", "Inventory Coordinator", "Claims Reviewer").contains(role)) {
            model.addAttribute("registerError", "Select a valid clinic role.");
            return "login";
        }
        clinicUserRepository.save(new ClinicUser(normalizedUsername, normalizedEmail, passwordEncoder.encode(password), name.trim(), role));
        redirectAttributes.addFlashAttribute("notice", "Account created. Sign in with your new clinic credentials.");
        return "redirect:/login";
    }

    @PostMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addLayout(model, session, "dashboard", "Dashboard");
        model.addAttribute("page", "dashboard");
        long patientCount = patientRepository.count();
        long vaccineCount = vaccineBatchRepository.count();
        long claimCount = insuranceClaimRepository.count();
        long storageCount = storageUnitRepository.count();
        long transactionCount = transactionRepository.count();
        model.addAttribute("patientCount", patientCount);
        model.addAttribute("vaccineCount", vaccineCount);
        model.addAttribute("claimCount", claimCount);
        model.addAttribute("storageCount", storageCount);
        List<ActivityMetric> activityMetrics = List.of(
            new ActivityMetric("Patients", patientCount),
            new ActivityMetric("Vaccine batches", vaccineCount),
            new ActivityMetric("Claims", claimCount),
            new ActivityMetric("Transactions", transactionCount),
            new ActivityMetric("Storage units", storageCount));
        model.addAttribute("activityMetrics", activityMetrics);
        model.addAttribute("activityMax", Math.max(1, activityMetrics.stream().mapToLong(ActivityMetric::count).max().orElse(0)));
        model.addAttribute("recentPatients", patientRepository.findAll().stream().limit(5).toList());
        model.addAttribute("totalBudget", budgetRepository.findAll().stream().map(Budget::getAllocatedAmount).filter(value -> value != null).reduce(BigDecimal.ZERO, BigDecimal::add));
        model.addAttribute("totalSpent", budgetRepository.findAll().stream().map(Budget::getSpentAmount).filter(value -> value != null).reduce(BigDecimal.ZERO, BigDecimal::add));
        return "clinic";
    }

    @GetMapping("/patients")
    public String patients(@RequestParam(defaultValue = "") String q,
                           @RequestParam(defaultValue = "all") String status,
                           HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        List<PageRow> rows = patientRepository.findAll().stream()
                .map(patient -> row(patient.getStatus(), patient.getId(), patient.getName(), patient.getAge(), patient.getGender(), patient.getVillage(), patient.getInsuranceProvider(), patient.getStatus()))
                .toList();
        return records(model, session, "patients", "Patients", "Care registry", "Keep patient records, coverage details, and follow-up status ready for the next clinic visit.",
                "/patients/new", List.of("ID", "Name", "Age", "Gender", "Village", "Insurance provider", "Status"), rows, q, status);
    }

    @GetMapping("/vaccines")
    public String vaccines(@RequestParam(defaultValue = "") String q,
                           @RequestParam(defaultValue = "all") String status,
                           HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        List<PageRow> rows = vaccineBatchRepository.findAll().stream()
                .map(batch -> row(batch.getQuantity() != null && batch.getQuantity() < 50 ? "Alert" : "Active",
                        batch.getVaccineName(), batch.getBatchCode(), batch.getSupplierName(), batch.getQuantity(), batch.getExpiryDate(), formatCurrency(batch.getUnitPrice())))
                .toList();
        return records(model, session, "vaccines", "Vaccines", "Immunization inventory", "Monitor batch quantities, expiry dates, and supply readiness across the clinic network.",
                "/vaccines/new", List.of("Vaccine", "Batch code", "Supplier", "Quantity", "Expiry date", "Unit price"), rows, q, status);
    }

    @GetMapping("/storage")
    public String storage(@RequestParam(defaultValue = "") String q,
                          @RequestParam(defaultValue = "all") String status,
                          HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        List<PageRow> rows = storageUnitRepository.findAll().stream()
                .map(unit -> row(unit.getStatus(), unit.getId(), unit.getName(), unit.getLocation(), unit.getCapacity(), unit.getMinTemperature(), unit.getMaxTemperature(), unit.getStatus()))
                .toList();
        return records(model, session, "storage", "Storage", "Cold-chain control", "Track storage capacity and protect temperature-sensitive supplies.",
                "/storage/new", List.of("ID", "Unit", "Location", "Capacity", "Min C", "Max C", "Status"), rows, q, status);
    }

    @GetMapping("/claims")
    public String claims(@RequestParam(defaultValue = "") String q,
                         @RequestParam(defaultValue = "all") String status,
                         HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        List<PageRow> rows = insuranceClaimRepository.findAll().stream()
                .map(claim -> row(claim.getStatus(), claim.getClaimNumber(), claim.getPatient() == null ? "Unassigned" : claim.getPatient().getName(), claim.getClaimDate(), formatCurrency(claim.getClaimAmount()), formatCurrency(claim.getApprovedAmount()), claim.getStatus()))
                .toList();
        return records(model, session, "claims", "Insurance Claims", "Revenue cycle", "Review submitted claims, approvals, and reimbursement progress.",
                "/claims/new", List.of("Claim number", "Patient", "Claim date", "Claim amount", "Approved amount", "Status"), rows, q, status);
    }

    @GetMapping("/budgets")
    public String budgets(@RequestParam(defaultValue = "") String q,
                          @RequestParam(defaultValue = "all") String status,
                          HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        List<PageRow> rows = budgetRepository.findAll().stream()
                .map(budget -> row("", budget.getFiscalYear(), budget.getCategory(), formatCurrency(budget.getAllocatedAmount()), formatCurrency(budget.getSpentAmount()), formatCurrency(safeAmount(budget.getAllocatedAmount()).subtract(safeAmount(budget.getSpentAmount())))))
                .toList();
        return records(model, session, "budgets", "Budgets", "Program finance", "See how each health program is performing against its allocated funding.",
                "/budgets/new", List.of("Fiscal year", "Program", "Allocated", "Spent", "Remaining"), rows, q, status);
    }

    @GetMapping("/transactions")
    public String transactions(@RequestParam(defaultValue = "") String q,
                               @RequestParam(defaultValue = "all") String status,
                               HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        List<PageRow> rows = transactionRepository.findAll().stream()
                .map(transaction -> row("", transaction.getTransactionDate(), transaction.getType(), transaction.getCategory(), transaction.getReference(), transaction.getDescription(), formatCurrency(transaction.getAmount())))
                .toList();
        return records(model, session, "transactions", "Transactions", "Financial ledger", "Record purchases, operating expenses, refunds, and other clinic movements.",
                "/transactions/new", List.of("Date", "Type", "Category", "Reference", "Description", "Amount"), rows, q, status);
    }

    @GetMapping({"/reports", "/reports/print"})
    public String reports(HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addLayout(model, session, "reports", "Reports");
        model.addAttribute("page", "reports");
        return "clinic";
    }

    @GetMapping("/vaccines.csv")
    public ResponseEntity<byte[]> exportVaccines(HttpSession session) {
        if (!isLoggedIn(session)) {
            return ResponseEntity.status(HttpStatus.FOUND).header(HttpHeaders.LOCATION, "/login").build();
        }
        List<String> lines = new ArrayList<>();
        lines.add("Vaccine,Supplier,Batch code,Quantity,Expiry date");
        vaccineBatchRepository.findAll().forEach(batch -> lines.add(String.join(",", csv(batch.getVaccineName()), csv(batch.getSupplierName()), csv(batch.getBatchCode()), csv(batch.getQuantity()), csv(batch.getExpiryDate()))));
        return ResponseEntity.ok().contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=vaccine-inventory.csv")
                .body(String.join("\r\n", lines).getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    @GetMapping("/patients/new")
    public String newPatient(HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        Patient patient = new Patient();
        patient.setInsuranceProvider("No Insurance");
        patient.setInsuranceId("N/A");
        patient.setStatus("Active");
        model.addAttribute("patient", patient);
        return formPage(model, session, "patient-form", "patients", "Add patient");
    }

    @PostMapping("/patients")
    public String savePatient(@Valid @ModelAttribute("patient") Patient patient, BindingResult result, HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        if (result.hasErrors()) return formPage(model, session, "patient-form", "patients", "Add patient");
        patientRepository.save(patient);
        return "redirect:/patients";
    }

    @GetMapping("/vaccines/new")
    public String newVaccine(HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        model.addAttribute("vaccine", new VaccineBatch());
        model.addAttribute("storageUnits", storageUnitRepository.findAll());
        return formPage(model, session, "vaccine-form", "vaccines", "Add vaccine batch");
    }

    @PostMapping("/vaccines")
    public String saveVaccine(@Valid @ModelAttribute("vaccine") VaccineBatch vaccine, BindingResult result,
                              @RequestParam(required = false) Long storageUnitId, HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        if (result.hasErrors()) {
            model.addAttribute("storageUnits", storageUnitRepository.findAll());
            return formPage(model, session, "vaccine-form", "vaccines", "Add vaccine batch");
        }
        if (storageUnitId != null) storageUnitRepository.findById(storageUnitId).ifPresent(vaccine::setStorageUnit);
        vaccineBatchRepository.save(vaccine);
        return "redirect:/vaccines";
    }

    @GetMapping("/storage/new")
    public String newStorage(HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        StorageUnit unit = new StorageUnit();
        unit.setStatus("Active");
        model.addAttribute("storageUnit", unit);
        return formPage(model, session, "storage-form", "storage", "Add storage unit");
    }

    @PostMapping("/storage")
    public String saveStorage(@Valid @ModelAttribute("storageUnit") StorageUnit unit, BindingResult result, HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        if (result.hasErrors()) return formPage(model, session, "storage-form", "storage", "Add storage unit");
        storageUnitRepository.save(unit);
        return "redirect:/storage";
    }

    @GetMapping("/claims/new")
    public String newClaim(HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        InsuranceClaim claim = new InsuranceClaim();
        claim.setStatus("Submitted");
        claim.setClaimDate(LocalDate.now());
        model.addAttribute("claim", claim);
        model.addAttribute("patients", patientRepository.findAll());
        return formPage(model, session, "claim-form", "claims", "Submit insurance claim");
    }

    @PostMapping("/claims")
    public String saveClaim(@Valid @ModelAttribute("claim") InsuranceClaim claim, BindingResult result,
                            @RequestParam(required = false) Long patientId, HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        if (result.hasErrors()) {
            model.addAttribute("patients", patientRepository.findAll());
            return formPage(model, session, "claim-form", "claims", "Submit insurance claim");
        }
        if (patientId != null) patientRepository.findById(patientId).ifPresent(claim::setPatient);
        insuranceClaimRepository.save(claim);
        return "redirect:/claims";
    }

    @GetMapping("/budgets/new")
    public String newBudget(HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        model.addAttribute("budget", new Budget());
        return formPage(model, session, "budget-form", "budgets", "Add budget");
    }

    @PostMapping("/budgets")
    public String saveBudget(@Valid @ModelAttribute("budget") Budget budget, BindingResult result, HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        if (result.hasErrors()) return formPage(model, session, "budget-form", "budgets", "Add budget");
        budgetRepository.save(budget);
        return "redirect:/budgets";
    }

    @GetMapping("/transactions/new")
    public String newTransaction(HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        Transaction transaction = new Transaction();
        transaction.setTransactionDate(LocalDate.now());
        model.addAttribute("transaction", transaction);
        return formPage(model, session, "transaction-form", "transactions", "Add transaction");
    }

    @PostMapping("/transactions")
    public String saveTransaction(@Valid @ModelAttribute("transaction") Transaction transaction, BindingResult result, HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        if (result.hasErrors()) return formPage(model, session, "transaction-form", "transactions", "Add transaction");
        transactionRepository.save(transaction);
        return "redirect:/transactions";
    }

    private String records(Model model, HttpSession session, String activePage, String title, String eyebrow,
                           String description, String formUrl, List<String> columns, List<PageRow> rows, String query, String status) {
        String normalizedQuery = query.trim().toLowerCase(Locale.ROOT);
        List<PageRow> filteredRows = rows.stream()
                .filter(row -> normalizedQuery.isEmpty() || row.searchableText().contains(normalizedQuery))
                .filter(row -> matchesStatus(row.status(), status))
                .toList();
        addLayout(model, session, activePage, title);
        model.addAttribute("page", "records");
        model.addAttribute("eyebrow", eyebrow);
        model.addAttribute("description", description);
        model.addAttribute("formUrl", formUrl);
        model.addAttribute("listUrl", "/" + activePage);
        model.addAttribute("csvUrl", "/vaccines.csv");
        model.addAttribute("columns", columns);
        model.addAttribute("rows", filteredRows);
        model.addAttribute("query", query);
        model.addAttribute("statusFilter", status);
        model.addAttribute("resultCount", filteredRows.size());
        model.addAttribute("totalCount", rows.size());
        return "clinic";
    }

    private String formPage(Model model, HttpSession session, String page, String activePage, String title) {
        addLayout(model, session, activePage, title);
        model.addAttribute("page", page);
        model.addAttribute("backUrl", "/" + activePage);
        return "clinic";
    }

    private void addLayout(Model model, HttpSession session, String activePage, String title) {
        model.addAttribute("activePage", activePage);
        model.addAttribute("pageTitle", title);
        model.addAttribute("userName", session.getAttribute(USER_NAME));
        model.addAttribute("userRole", session.getAttribute(USER_ROLE));
    }

    private boolean isLoggedIn(HttpSession session) {
        return session.getAttribute(USER_NAME) != null;
    }

    private boolean matchesStatus(String rowStatus, String filter) {
        if (filter == null || filter.isBlank() || "all".equalsIgnoreCase(filter)) return true;
        if ("Pending".equalsIgnoreCase(filter)) {
            return !List.of("active", "approved", "rejected", "completed").contains(rowStatus.toLowerCase(Locale.ROOT));
        }
        return rowStatus.equalsIgnoreCase(filter);
    }

    private static PageRow row(String status, Object... values) {
        List<String> cells = java.util.Arrays.stream(values).map(HtmlPageController::text).toList();
        String searchableText = String.join(" ", cells).toLowerCase(Locale.ROOT);
        return new PageRow(cells, searchableText, status == null ? "" : status);
    }

    private static String text(Object value) {
        return value == null ? "" : value.toString();
    }

    private static String formatCurrency(BigDecimal value) {
        NumberFormat format = NumberFormat.getNumberInstance(Locale.forLanguageTag("en-IN"));
        format.setMaximumFractionDigits(2);
        return "INR " + format.format(value == null ? BigDecimal.ZERO : value);
    }

    private static BigDecimal safeAmount(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    private static String csv(Object value) {
        return "\"" + text(value).replace("\"", "\"\"") + "\"";
    }

    private record ActivityMetric(String label, long count) {}
    private record PageRow(List<String> cells, String searchableText, String status) {}
}