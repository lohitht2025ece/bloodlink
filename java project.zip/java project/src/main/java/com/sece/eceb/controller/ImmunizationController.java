package com.sece.eceb.controller;

import com.sece.eceb.entity.Immunization;
import com.sece.eceb.repository.ImmunizationRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/immunizations")
@SuppressWarnings("null")
public class ImmunizationController {
    private final ImmunizationRepository immunizationRepository;

    public ImmunizationController(ImmunizationRepository immunizationRepository) {
        this.immunizationRepository = immunizationRepository;
    }

    @GetMapping
    public List<Immunization> getAll() { return immunizationRepository.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Immunization> getById(@PathVariable Long id) {
        return immunizationRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Immunization create(@Valid @RequestBody Immunization immunization) { return immunizationRepository.save(immunization); }

    @PutMapping("/{id}")
    public ResponseEntity<Immunization> update(@PathVariable Long id, @Valid @RequestBody Immunization request) {
        return immunizationRepository.findById(id)
                .map(existing -> {
                    existing.setPatient(request.getPatient());
                    existing.setVaccineBatch(request.getVaccineBatch());
                    existing.setDoseNumber(request.getDoseNumber());
                    existing.setAdministeredAt(request.getAdministeredAt());
                    existing.setSite(request.getSite());
                    existing.setStatus(request.getStatus());
                    return ResponseEntity.ok(immunizationRepository.save(existing));
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (immunizationRepository.existsById(id)) {
            immunizationRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
