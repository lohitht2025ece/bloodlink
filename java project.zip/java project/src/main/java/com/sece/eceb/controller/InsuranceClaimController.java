package com.sece.eceb.controller;

import com.sece.eceb.entity.InsuranceClaim;
import com.sece.eceb.repository.InsuranceClaimRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.jspecify.annotations.NonNull;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/claims")
@SuppressWarnings("null")
public class InsuranceClaimController {
    private final InsuranceClaimRepository insuranceClaimRepository;

    public InsuranceClaimController(InsuranceClaimRepository insuranceClaimRepository) {
        this.insuranceClaimRepository = insuranceClaimRepository;
    }

    @GetMapping
    public List<InsuranceClaim> getAll() { return insuranceClaimRepository.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<InsuranceClaim> getById(@PathVariable @NonNull Long id) {
        return insuranceClaimRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public InsuranceClaim create(@Valid @RequestBody @NonNull InsuranceClaim insuranceClaim) { return insuranceClaimRepository.save(insuranceClaim); }

    @PutMapping("/{id}")
    public ResponseEntity<InsuranceClaim> update(@PathVariable @NonNull Long id, @Valid @RequestBody @NonNull InsuranceClaim request) {
        return insuranceClaimRepository.findById(id)
                .map(existing -> {
                    existing.setPatient(request.getPatient());
                    existing.setClaimNumber(request.getClaimNumber());
                    existing.setClaimAmount(request.getClaimAmount());
                    existing.setStatus(request.getStatus());
                    existing.setClaimDate(request.getClaimDate());
                    existing.setApprovedAmount(request.getApprovedAmount());
                    existing.setNotes(request.getNotes());
                    return ResponseEntity.ok(insuranceClaimRepository.save(existing));
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable @NonNull Long id) {
        if (insuranceClaimRepository.existsById(id)) {
            insuranceClaimRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
