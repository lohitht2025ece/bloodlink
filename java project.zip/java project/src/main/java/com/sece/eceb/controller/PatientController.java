package com.sece.eceb.controller;

import com.sece.eceb.entity.Patient;
import com.sece.eceb.repository.PatientRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.jspecify.annotations.NonNull;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
@SuppressWarnings("null")
public class PatientController {
    private final PatientRepository patientRepository;

    public PatientController(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    @GetMapping
    public List<Patient> getAll() { return patientRepository.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Patient> getById(@PathVariable @NonNull Long id) {
        return patientRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Patient create(@Valid @RequestBody @NonNull Patient patient) { return patientRepository.save(patient); }

    @PutMapping("/{id}")
    public ResponseEntity<Patient> update(@PathVariable @NonNull Long id, @Valid @RequestBody @NonNull Patient request) {
        return patientRepository.findById(id)
                .map(existing -> {
                    existing.setName(request.getName());
                    existing.setAge(request.getAge());
                    existing.setGender(request.getGender());
                    existing.setVillage(request.getVillage());
                    existing.setPhone(request.getPhone());
                    existing.setInsuranceProvider(request.getInsuranceProvider());
                    existing.setInsuranceId(request.getInsuranceId());
                    existing.setStatus(request.getStatus());
                    return ResponseEntity.ok(patientRepository.save(existing));
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable @NonNull Long id) {
        if (patientRepository.existsById(id)) {
            patientRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
