package com.sece.eceb.controller;

import com.sece.eceb.entity.StorageUnit;
import com.sece.eceb.repository.StorageUnitRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.jspecify.annotations.NonNull;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/storage")
@SuppressWarnings("null")
public class StorageController {
    private final StorageUnitRepository storageUnitRepository;

    public StorageController(StorageUnitRepository storageUnitRepository) {
        this.storageUnitRepository = storageUnitRepository;
    }

    @GetMapping
    public List<StorageUnit> getAll() { return storageUnitRepository.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<StorageUnit> getById(@PathVariable @NonNull Long id) {
        return storageUnitRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public StorageUnit create(@Valid @RequestBody @NonNull StorageUnit storageUnit) { return storageUnitRepository.save(storageUnit); }

    @PutMapping("/{id}")
    public ResponseEntity<StorageUnit> update(@PathVariable @NonNull Long id, @Valid @RequestBody @NonNull StorageUnit request) {
        return storageUnitRepository.findById(id)
                .map(existing -> {
                    existing.setName(request.getName());
                    existing.setLocation(request.getLocation());
                    existing.setCapacity(request.getCapacity());
                    existing.setMinTemperature(request.getMinTemperature());
                    existing.setMaxTemperature(request.getMaxTemperature());
                    existing.setStatus(request.getStatus());
                    return ResponseEntity.ok(storageUnitRepository.save(existing));
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable @NonNull Long id) {
        if (storageUnitRepository.existsById(id)) {
            storageUnitRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
