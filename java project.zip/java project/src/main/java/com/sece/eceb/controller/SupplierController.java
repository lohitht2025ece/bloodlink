package com.sece.eceb.controller;

import com.sece.eceb.entity.Supplier;
import com.sece.eceb.repository.SupplierRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.jspecify.annotations.NonNull;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/suppliers")
@SuppressWarnings("null")
public class SupplierController {
    private final SupplierRepository supplierRepository;

    public SupplierController(SupplierRepository supplierRepository) {
        this.supplierRepository = supplierRepository;
    }

    @GetMapping
    public List<Supplier> getAll() { return supplierRepository.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Supplier> getById(@PathVariable @NonNull Long id) {
        return supplierRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Supplier create(@Valid @RequestBody @NonNull Supplier supplier) { return supplierRepository.save(supplier); }

    @PutMapping("/{id}")
    public ResponseEntity<Supplier> update(@PathVariable @NonNull Long id, @Valid @RequestBody @NonNull Supplier request) {
        return supplierRepository.findById(id)
                .map(existing -> {
                    existing.setName(request.getName());
                    existing.setContactPerson(request.getContactPerson());
                    existing.setPhone(request.getPhone());
                    existing.setAddress(request.getAddress());
                    existing.setCategory(request.getCategory());
                    return ResponseEntity.ok(supplierRepository.save(existing));
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable @NonNull Long id) {
        if (supplierRepository.existsById(id)) {
            supplierRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
