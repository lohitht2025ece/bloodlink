package com.sece.eceb.controller;

import com.sece.eceb.entity.Transaction;
import com.sece.eceb.repository.TransactionRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@SuppressWarnings("null")
public class TransactionController {
    private final TransactionRepository transactionRepository;

    public TransactionController(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    @GetMapping
    public List<Transaction> getAll() { return transactionRepository.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Transaction> getById(@PathVariable Long id) {
        return transactionRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Transaction create(@Valid @RequestBody Transaction transaction) { return transactionRepository.save(transaction); }

    @PutMapping("/{id}")
    public ResponseEntity<Transaction> update(@PathVariable Long id, @Valid @RequestBody Transaction request) {
        return transactionRepository.findById(id)
                .map(existing -> {
                    existing.setType(request.getType());
                    existing.setAmount(request.getAmount());
                    existing.setDescription(request.getDescription());
                    existing.setTransactionDate(request.getTransactionDate());
                    existing.setReference(request.getReference());
                    existing.setCategory(request.getCategory());
                    return ResponseEntity.ok(transactionRepository.save(existing));
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (transactionRepository.existsById(id)) {
            transactionRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
