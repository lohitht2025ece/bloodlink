package com.sece.eceb.controller;

import com.sece.eceb.entity.VaccineBatch;
import com.sece.eceb.repository.VaccineBatchRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vaccines")
@SuppressWarnings("null")
public class VaccineController {
    private final VaccineBatchRepository vaccineBatchRepository;

    public VaccineController(VaccineBatchRepository vaccineBatchRepository) {
        this.vaccineBatchRepository = vaccineBatchRepository;
    }

    @GetMapping
    public List<VaccineBatch> getAll() { return vaccineBatchRepository.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<VaccineBatch> getById(@PathVariable Long id) {
        return vaccineBatchRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public VaccineBatch create(@Valid @RequestBody VaccineBatch vaccineBatch) { return vaccineBatchRepository.save(vaccineBatch); }

    @PutMapping("/{id}")
    public ResponseEntity<VaccineBatch> update(@PathVariable Long id, @Valid @RequestBody VaccineBatch request) {
        return vaccineBatchRepository.findById(id)
                .map(existing -> {
                    existing.setVaccineName(request.getVaccineName());
                    existing.setSupplierName(request.getSupplierName());
                    existing.setQuantity(request.getQuantity());
                    existing.setExpiryDate(request.getExpiryDate());
                    existing.setStorageUnit(request.getStorageUnit());
                    existing.setBatchCode(request.getBatchCode());
                    existing.setManufactureDate(request.getManufactureDate());
                    existing.setUnitPrice(request.getUnitPrice());
                    return ResponseEntity.ok(vaccineBatchRepository.save(existing));
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (vaccineBatchRepository.existsById(id)) {
            vaccineBatchRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
