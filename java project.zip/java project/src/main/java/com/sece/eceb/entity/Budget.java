package com.sece.eceb.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

@Entity
@Table(name = "budgets")
public class Budget {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String fiscalYear;

    @NotNull
    private BigDecimal allocatedAmount;

    @NotNull
    private BigDecimal spentAmount;

    @NotBlank
    private String category;

    public Budget() {}

    public Budget(String fiscalYear, BigDecimal allocatedAmount, BigDecimal spentAmount, String category) {
        this.fiscalYear = fiscalYear;
        this.allocatedAmount = allocatedAmount;
        this.spentAmount = spentAmount;
        this.category = category;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getFiscalYear() { return fiscalYear; }
    public void setFiscalYear(String fiscalYear) { this.fiscalYear = fiscalYear; }
    public BigDecimal getAllocatedAmount() { return allocatedAmount; }
    public void setAllocatedAmount(BigDecimal allocatedAmount) { this.allocatedAmount = allocatedAmount; }
    public BigDecimal getSpentAmount() { return spentAmount; }
    public void setSpentAmount(BigDecimal spentAmount) { this.spentAmount = spentAmount; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
}
