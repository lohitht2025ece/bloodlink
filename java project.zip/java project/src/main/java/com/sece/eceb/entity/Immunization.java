package com.sece.eceb.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

@Entity
@Table(name = "immunizations")
public class Immunization {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "patient_id")
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "vaccine_batch_id")
    private VaccineBatch vaccineBatch;

    @NotNull
    private Integer doseNumber;

    @NotNull
    private LocalDateTime administeredAt;

    @NotBlank
    private String site;

    private String status;

    public Immunization() {}

    public Immunization(Patient patient, VaccineBatch vaccineBatch, Integer doseNumber, LocalDateTime administeredAt, String site, String status) {
        this.patient = patient;
        this.vaccineBatch = vaccineBatch;
        this.doseNumber = doseNumber;
        this.administeredAt = administeredAt;
        this.site = site;
        this.status = status;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Patient getPatient() { return patient; }
    public void setPatient(Patient patient) { this.patient = patient; }
    public VaccineBatch getVaccineBatch() { return vaccineBatch; }
    public void setVaccineBatch(VaccineBatch vaccineBatch) { this.vaccineBatch = vaccineBatch; }
    public Integer getDoseNumber() { return doseNumber; }
    public void setDoseNumber(Integer doseNumber) { this.doseNumber = doseNumber; }
    public LocalDateTime getAdministeredAt() { return administeredAt; }
    public void setAdministeredAt(LocalDateTime administeredAt) { this.administeredAt = administeredAt; }
    public String getSite() { return site; }
    public void setSite(String site) { this.site = site; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
