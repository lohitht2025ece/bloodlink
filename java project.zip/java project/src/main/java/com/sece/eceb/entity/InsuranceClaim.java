package com.sece.eceb.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "insurance_claims")
public class InsuranceClaim {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "patient_id")
    private Patient patient;

    @NotBlank
    private String claimNumber;

    @NotNull
    private BigDecimal claimAmount;

    private String status;

    @NotNull
    private LocalDate claimDate;

    @NotNull
    private BigDecimal approvedAmount;

    private String notes;

    public InsuranceClaim() {}

    public InsuranceClaim(Patient patient, String claimNumber, BigDecimal claimAmount, String status, LocalDate claimDate, BigDecimal approvedAmount, String notes) {
        this.patient = patient;
        this.claimNumber = claimNumber;
        this.claimAmount = claimAmount;
        this.status = status;
        this.claimDate = claimDate;
        this.approvedAmount = approvedAmount;
        this.notes = notes;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Patient getPatient() { return patient; }
    public void setPatient(Patient patient) { this.patient = patient; }
    public String getClaimNumber() { return claimNumber; }
    public void setClaimNumber(String claimNumber) { this.claimNumber = claimNumber; }
    public BigDecimal getClaimAmount() { return claimAmount; }
    public void setClaimAmount(BigDecimal claimAmount) { this.claimAmount = claimAmount; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDate getClaimDate() { return claimDate; }
    public void setClaimDate(LocalDate claimDate) { this.claimDate = claimDate; }
    public BigDecimal getApprovedAmount() { return approvedAmount; }
    public void setApprovedAmount(BigDecimal approvedAmount) { this.approvedAmount = approvedAmount; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
