package com.sece.eceb.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "patients")
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String name;

    @NotNull
    private Integer age;

    @NotBlank
    private String gender;

    @NotBlank
    private String village;

    @NotBlank
    private String phone;

    private String insuranceProvider;
    private String insuranceId;
    private String status;

    public Patient() {}

    public Patient(String name, Integer age, String gender, String village, String phone, String insuranceProvider, String insuranceId, String status) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.village = village;
        this.phone = phone;
        this.insuranceProvider = insuranceProvider;
        this.insuranceId = insuranceId;
        this.status = status;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    public String getVillage() { return village; }
    public void setVillage(String village) { this.village = village; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getInsuranceProvider() { return insuranceProvider; }
    public void setInsuranceProvider(String insuranceProvider) { this.insuranceProvider = insuranceProvider; }
    public String getInsuranceId() { return insuranceId; }
    public void setInsuranceId(String insuranceId) { this.insuranceId = insuranceId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
