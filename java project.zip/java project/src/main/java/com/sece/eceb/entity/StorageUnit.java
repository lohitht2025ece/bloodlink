package com.sece.eceb.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "storage_units")
public class StorageUnit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String name;

    @NotBlank
    private String location;

    @NotNull
    private Integer capacity;

    @NotNull
    private Double minTemperature;

    @NotNull
    private Double maxTemperature;

    private String status;

    public StorageUnit() {}

    public StorageUnit(String name, String location, Integer capacity, Double minTemperature, Double maxTemperature, String status) {
        this.name = name;
        this.location = location;
        this.capacity = capacity;
        this.minTemperature = minTemperature;
        this.maxTemperature = maxTemperature;
        this.status = status;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public Integer getCapacity() { return capacity; }
    public void setCapacity(Integer capacity) { this.capacity = capacity; }
    public Double getMinTemperature() { return minTemperature; }
    public void setMinTemperature(Double minTemperature) { this.minTemperature = minTemperature; }
    public Double getMaxTemperature() { return maxTemperature; }
    public void setMaxTemperature(Double maxTemperature) { this.maxTemperature = maxTemperature; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
