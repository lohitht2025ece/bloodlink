package com.sece.eceb.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

@Entity
@Table(name = "temperature_logs")
public class TemperatureLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "storage_unit_id")
    private StorageUnit storageUnit;

    @NotNull
    private Double temperature;

    private String status;

    @NotNull
    private LocalDateTime loggedAt;

    public TemperatureLog() {}

    public TemperatureLog(StorageUnit storageUnit, Double temperature, String status, LocalDateTime loggedAt) {
        this.storageUnit = storageUnit;
        this.temperature = temperature;
        this.status = status;
        this.loggedAt = loggedAt;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public StorageUnit getStorageUnit() { return storageUnit; }
    public void setStorageUnit(StorageUnit storageUnit) { this.storageUnit = storageUnit; }
    public Double getTemperature() { return temperature; }
    public void setTemperature(Double temperature) { this.temperature = temperature; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getLoggedAt() { return loggedAt; }
    public void setLoggedAt(LocalDateTime loggedAt) { this.loggedAt = loggedAt; }
}
