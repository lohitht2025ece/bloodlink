package com.sece.eceb.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "vaccine_batches")
public class VaccineBatch {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String vaccineName;

    @NotBlank
    private String supplierName;

    @NotNull
    private Integer quantity;

    @NotNull
    private LocalDate expiryDate;

    @ManyToOne
    @JoinColumn(name = "storage_unit_id")
    private StorageUnit storageUnit;

    @NotBlank
    private String batchCode;

    @NotNull
    private LocalDate manufactureDate;

    @NotNull
    private BigDecimal unitPrice;

    public VaccineBatch() {}

    public VaccineBatch(String vaccineName, String supplierName, Integer quantity, LocalDate expiryDate, StorageUnit storageUnit, String batchCode, LocalDate manufactureDate, BigDecimal unitPrice) {
        this.vaccineName = vaccineName;
        this.supplierName = supplierName;
        this.quantity = quantity;
        this.expiryDate = expiryDate;
        this.storageUnit = storageUnit;
        this.batchCode = batchCode;
        this.manufactureDate = manufactureDate;
        this.unitPrice = unitPrice;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getVaccineName() { return vaccineName; }
    public void setVaccineName(String vaccineName) { this.vaccineName = vaccineName; }
    public String getSupplierName() { return supplierName; }
    public void setSupplierName(String supplierName) { this.supplierName = supplierName; }
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    public LocalDate getExpiryDate() { return expiryDate; }
    public void setExpiryDate(LocalDate expiryDate) { this.expiryDate = expiryDate; }
    public StorageUnit getStorageUnit() { return storageUnit; }
    public void setStorageUnit(StorageUnit storageUnit) { this.storageUnit = storageUnit; }
    public String getBatchCode() { return batchCode; }
    public void setBatchCode(String batchCode) { this.batchCode = batchCode; }
    public LocalDate getManufactureDate() { return manufactureDate; }
    public void setManufactureDate(LocalDate manufactureDate) { this.manufactureDate = manufactureDate; }
    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice) { this.unitPrice = unitPrice; }
}
