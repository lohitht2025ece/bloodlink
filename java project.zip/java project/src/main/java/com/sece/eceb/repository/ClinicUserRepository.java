package com.sece.eceb.repository;

import com.sece.eceb.entity.ClinicUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ClinicUserRepository extends JpaRepository<ClinicUser, Long> {
    Optional<ClinicUser> findByUsernameIgnoreCase(String username);
    Optional<ClinicUser> findByEmailIgnoreCase(String email);
    boolean existsByUsernameIgnoreCase(String username);
    boolean existsByEmailIgnoreCase(String email);
}