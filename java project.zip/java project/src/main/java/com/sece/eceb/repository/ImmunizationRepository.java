package com.sece.eceb.repository;

import com.sece.eceb.entity.Immunization;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ImmunizationRepository extends JpaRepository<Immunization, Long> {
}
