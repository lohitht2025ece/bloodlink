package com.sece.eceb.repository;

import com.sece.eceb.entity.StorageUnit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StorageUnitRepository extends JpaRepository<StorageUnit, Long> {
}
