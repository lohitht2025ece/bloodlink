package com.sece.eceb.repository;

import com.sece.eceb.entity.TemperatureLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TemperatureLogRepository extends JpaRepository<TemperatureLog, Long> {
}
