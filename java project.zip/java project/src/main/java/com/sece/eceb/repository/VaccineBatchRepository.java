package com.sece.eceb.repository;

import com.sece.eceb.entity.VaccineBatch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VaccineBatchRepository extends JpaRepository<VaccineBatch, Long> {
}
