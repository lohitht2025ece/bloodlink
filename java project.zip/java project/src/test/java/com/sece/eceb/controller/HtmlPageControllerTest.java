package com.sece.eceb.controller;

import com.sece.eceb.entity.Patient;
import com.sece.eceb.entity.ClinicUser;
import com.sece.eceb.repository.BudgetRepository;
import com.sece.eceb.repository.ClinicUserRepository;
import com.sece.eceb.repository.InsuranceClaimRepository;
import com.sece.eceb.repository.PatientRepository;
import com.sece.eceb.repository.StorageUnitRepository;
import com.sece.eceb.repository.TransactionRepository;
import com.sece.eceb.repository.VaccineBatchRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.MockMvc;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.spring6.view.ThymeleafViewResolver;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

import java.util.List;
import java.util.Optional;

import org.mockito.ArgumentCaptor;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

class HtmlPageControllerTest {
    private MockMvc mockMvc;

    private PatientRepository patientRepository;
    private VaccineBatchRepository vaccineBatchRepository;
    private StorageUnitRepository storageUnitRepository;
    private InsuranceClaimRepository insuranceClaimRepository;
    private BudgetRepository budgetRepository;
    private TransactionRepository transactionRepository;
    private ClinicUserRepository clinicUserRepository;

    @BeforeEach
    void configureMvc() {
        patientRepository = Mockito.mock(PatientRepository.class);
        vaccineBatchRepository = Mockito.mock(VaccineBatchRepository.class);
        storageUnitRepository = Mockito.mock(StorageUnitRepository.class);
        insuranceClaimRepository = Mockito.mock(InsuranceClaimRepository.class);
        budgetRepository = Mockito.mock(BudgetRepository.class);
        transactionRepository = Mockito.mock(TransactionRepository.class);
        clinicUserRepository = Mockito.mock(ClinicUserRepository.class);
        when(patientRepository.findAll()).thenReturn(List.of());
        when(vaccineBatchRepository.findAll()).thenReturn(List.of());
        when(storageUnitRepository.findAll()).thenReturn(List.of());
        when(insuranceClaimRepository.findAll()).thenReturn(List.of());
        when(budgetRepository.findAll()).thenReturn(List.of());
        when(transactionRepository.findAll()).thenReturn(List.of());

        ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
        templateResolver.setPrefix("templates/");
        templateResolver.setSuffix(".html");
        templateResolver.setTemplateMode(TemplateMode.HTML);
        templateResolver.setCharacterEncoding("UTF-8");
        templateResolver.setCacheable(false);

        SpringTemplateEngine templateEngine = new SpringTemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);
        ThymeleafViewResolver viewResolver = new ThymeleafViewResolver();
        viewResolver.setTemplateEngine(templateEngine);
        viewResolver.setCharacterEncoding("UTF-8");

        HtmlPageController controller = new HtmlPageController(patientRepository, vaccineBatchRepository, storageUnitRepository,
                insuranceClaimRepository, budgetRepository, transactionRepository, clinicUserRepository);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).setViewResolvers(viewResolver).build();
    }

    @Test
    void loginPageRendersWithoutClientScripts() throws Exception {
        mockMvc.perform(get("/login"))
                .andExpect(status().isOk())
                .andExpect(view().name("login"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("action=\"/login\"")))
                .andExpect(content().string(org.hamcrest.Matchers.not(org.hamcrest.Matchers.containsString("<script"))));
        mockMvc.perform(get("/")).andExpect(status().isOk()).andExpect(view().name("login"));
    }

    @Test
    void dashboardAndOperationalPagesRenderAsHtml() throws Exception {
        MockHttpSession session = authenticatedSession();
        for (String path : List.of("/dashboard", "/patients", "/vaccines", "/storage", "/claims", "/budgets", "/transactions", "/reports", "/reports/print")) {
            mockMvc.perform(get(path).session(session))
                    .andExpect(status().isOk())
                    .andExpect(view().name("clinic"));
        }
    }

    @Test
    void allDataEntryFormsRenderAsHtml() throws Exception {
        MockHttpSession session = authenticatedSession();
        for (String path : List.of("/patients/new", "/vaccines/new", "/storage/new", "/claims/new", "/budgets/new", "/transactions/new")) {
            mockMvc.perform(get(path).session(session))
                    .andExpect(status().isOk())
                    .andExpect(view().name("clinic"));
        }
    }

    @Test
    void patientFormUsesStandardPostSubmission() throws Exception {
        mockMvc.perform(post("/patients").session(authenticatedSession())
                        .param("name", "Test Patient")
                        .param("age", "24")
                        .param("gender", "Female")
                        .param("village", "Test Village")
                        .param("phone", "1234567890")
                        .param("insuranceProvider", "No Insurance")
                        .param("insuranceId", "N/A")
                        .param("status", "Active"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/patients"));
        verify(patientRepository).save(any(Patient.class));
    }

    @Test
    void registrationStoresHashedPasswordAndAllowsSignIn() throws Exception {
        when(clinicUserRepository.existsByUsernameIgnoreCase(anyString())).thenReturn(false);
        when(clinicUserRepository.existsByEmailIgnoreCase(anyString())).thenReturn(false);
        mockMvc.perform(post("/register")
                        .param("name", "Clinic User")
                        .param("email", "user@clinic.org")
                        .param("username", "clinic-user")
                        .param("password", "SecurePass1")
                        .param("confirmPassword", "SecurePass1")
                        .param("role", "Clinic Officer"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));

        ArgumentCaptor<ClinicUser> accountCaptor = ArgumentCaptor.forClass(ClinicUser.class);
        verify(clinicUserRepository).save(accountCaptor.capture());
        ClinicUser account = accountCaptor.getValue();
        assertNotEquals("SecurePass1", account.getPasswordHash());
        assertTrue(account.getPasswordHash().startsWith("$2"));
        when(clinicUserRepository.findByUsernameIgnoreCase("clinic-user")).thenReturn(Optional.of(account));

        mockMvc.perform(post("/login").param("username", "clinic-user").param("password", "SecurePass1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/dashboard"));
    }

    @Test
    void demoAccountAcceptsUsernameOrEmail() throws Exception {
        for (String identifier : List.of("admin", "admin@ruralcare.org")) {
            mockMvc.perform(post("/login").param("username", identifier).param("password", "admin123"))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/dashboard"));
        }
    }

    private MockHttpSession authenticatedSession() {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("clinicUserName", "Clinic Administrator");
        session.setAttribute("clinicUserRole", "Clinic Officer");
        return session;
    }
}